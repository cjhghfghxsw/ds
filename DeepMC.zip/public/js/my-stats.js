document.addEventListener('DOMContentLoaded', () => {
    loadMyStats();
});

async function loadMyStats() {
    const container = document.getElementById('my-stats-area');

    try {
        const response = await fetch('/api/my-stats');
        if (!response.ok) throw new Error('Could not load your stats.');
        
        const stats = await response.json();

        const rankDisplay = {
            'owner': 'Owner', 'manager': 'Manager', 'headadmin': 'Head-Admin',
            'admin': 'Admin', 'seniormod': 'Sr. Mod', 'mod': 'Mod'
        };

        const createPvpCard = () => {
            if (stats.points === null && stats.kills === null) return '';
            return `
                <div class="stats-card">
                    <h2>PvP Stats</h2>
                    <div class="stat-item">
                        <span class="stat-label">Points</span>
                        <span class="stat-value">${stats.points || 0}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Kills</span>
                        <span class="stat-value">${stats.kills || 0}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Deaths</span>
                        <span class="stat-value">${stats.deaths || 0}</span>
                    </div>
                </div>
            `;
        };

        const html = `
            <div class="profile-content-wrapper" style="margin-top: 40px;">
                <h1 class="page-title">Your Personal Statistics</h1>
                <div class="profile-stats-grid">
                    <div class="stats-card">
                        <h2>General Info</h2>
                        <div class="stat-item">
                            <span class="stat-label">Rank</span>
                            <span class="stat-value">${rankDisplay[stats.primary_group] || stats.primary_group}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Playtime</span>
                            <span class="stat-value">${formatPlaytime(stats.playtime)}</span>
                        </div>
                    </div>
                    ${createPvpCard()}
                </div>
            </div>
        `;
        container.innerHTML = html;

    } catch (error) {
        container.innerHTML = `<h1 class="loading-text">Error: ${error.message}</h1>`;
    }
}

// Helper function to format playtime
function formatPlaytime(totalSeconds) {
    if (!totalSeconds) return 'N/A';
    if (totalSeconds < 60) return `${totalSeconds}s`;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    return `${hours}h ${minutes}m`;
}