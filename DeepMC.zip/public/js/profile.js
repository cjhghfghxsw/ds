document.addEventListener('DOMContentLoaded', () => {
    loadProfile();
});

// Fetches and displays the profile data for the user in the URL
async function loadProfile() {
    const container = document.getElementById('profile-area');
    const username = window.location.pathname.split('/').pop();

    if (!username) {
        container.innerHTML = '<h1 class="loading-text">No player specified.</h1>';
        return;
    }

    try {
        const response = await fetch(`/api/player/${username}`);
        if (!response.ok) {
            // If player not found, redirect to homepage
            window.location.href = '/';
            return;
        }
        
        const player = await response.json();

        const playerUUID = player.uuid ? player.uuid.replace(/-/g, '') : 'steve';
        const rankDisplay = {
            'owner': 'Owner', 'manager': 'Manager', 'headadmin': 'Head-Admin',
            'admin': 'Admin', 'seniormod': 'Sr. Mod', 'mod': 'Mod'
        };

        const createPvpCard = () => {
            if (player.points === null && player.kills === null) return '';
            return `
                <div class="stats-card">
                    <h2><i class="fas fa-swords stat-icon"></i> PvP Stats</h2>
                    <div class="stat-item">
                        <i class="fas fa-star stat-icon"></i>
                        <div class="stat-details">
                            <span class="stat-label">Points</span>
                            <span class="stat-value">${player.points || 0}</span>
                        </div>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-skull stat-icon"></i>
                        <div class="stat-details">
                            <span class="stat-label">Kills</span>
                            <span class="stat-value">${player.kills || 0}</span>
                        </div>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-crosshairs stat-icon"></i>
                        <div class="stat-details">
                            <span class="stat-label">Deaths</span>
                            <span class="stat-value">${player.deaths || 0}</span>
                        </div>
                    </div>
                </div>
            `;
        };

        const html = `
            <div class="profile-banner"></div>
            <div class="profile-content-wrapper">
                <div class="profile-header">
                    <img class="profile-avatar" src="https://cravatar.eu/helmavatar/${playerUUID}/160.png?default=steve" alt="${player.username}'s skin">
                    <div class="profile-identity">
                        <h1 style="${player.colorStyle}">${player.username}</h1>
                        <p>${rankDisplay[player.primary_group] || player.primary_group}</p>
                    </div>
                </div>
                <div class="profile-stats-container">
                    <div class="stats-card">
                        <h2><i class="fas fa-info-circle stat-icon"></i> General Info</h2>
                        <div class="stat-item">
                            <i class="fas fa-power-off stat-icon"></i>
                            <div class="stat-details">
                                <span class="stat-label">Status</span>
                                <span class="stat-value ${player.is_logged_in ? 'online' : 'offline'}">
                                    ${player.is_logged_in ? 'Online' : 'Offline'}
                                </span>
                            </div>
                        </div>
                        <div class="stat-item">
                            <i class="fas fa-clock stat-icon"></i>
                            <div class="stat-details">
                                <span class="stat-label">Playtime</span>
                                <span class="stat-value">${formatPlaytime(player.playtime)}</span>
                            </div>
                        </div>
                    </div>
                    ${createPvpCard()}
                </div>
            </div>
        `;
        container.innerHTML = html;

    } catch (error) {
        container.innerHTML = `<h1 class="loading-text">Error: ${error.message}</h1>`;
    }
}

// Helper function to format playtime from seconds into a human-readable string
function formatPlaytime(totalSeconds) {
    if (!totalSeconds) return 'N/A';
    if (totalSeconds < 60) return `${totalSeconds}s`;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    return `${hours}h ${minutes}m`;
}
// Make sure this helper function is still in the file
function formatPlaytime(totalSeconds) {
    if (!totalSeconds) return 'N/A';
    if (totalSeconds < 60) return `${totalSeconds}s`;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    return `${hours}h ${minutes}m`;
}


// Make sure this helper function is still in the file
function formatPlaytime(totalSeconds) {
    if (!totalSeconds) return 'N/A';
    if (totalSeconds < 60) return `${totalSeconds}s`;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    return `${hours}h ${minutes}m`;
}

// Formats playtime from seconds into a human-readable string
function formatPlaytime(totalSeconds) {
    if (!totalSeconds) return 'N/A';
    if (totalSeconds < 60) return `${totalSeconds}s`;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    return `${hours}h ${minutes}m`;
}