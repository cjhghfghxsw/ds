const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const session = require('express-session');

const config = require('./config.json');

const app = express();
const PORT = 3000;

// --- Session Middleware Setup ---
app.use(session({
    secret: 'a-very-secret-key-that-you-should-change',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// --- Database Connection Pool ---
const dbPool = mysql.createPool({
    host: config.DB_HOST,
    port: config.DB_PORT,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    database: config.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// --- General Middleware ---
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


// --- Helper Functions ---

// Middleware to check if a user is logged in (for protecting sensitive APIs)
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        return next();
    }
    res.status(401).json({ error: 'Not authenticated' }); // Send error for API calls
};
const isStaff = (req, res, next) => {
    if (req.session.user) {
        const staffRanks = ['mod', 'seniormod', 'admin', 'headadmin', 'manager', 'owner'];
        if (staffRanks.includes(req.session.user.primary_group)) {
            return next(); // User is staff, proceed
        }
    }
    // If not staff, send a 404 error
    res.status(404).send('Page not found');
};
// Minecraft Color Code Parser
function parseMinecraftColors(permissionString) {
    const colorMap = {
        '&0': '#000000', '&1': '#0000AA', '&2': '#00AA00', '&3': '#00AAAA',
        '&4': '#AA0000', '&5': '#AA00AA', '&6': '#FFAA00', '&7': '#AAAAAA',
        '&8': '#555555', '&9': '#5555FF', '&a': '#55FF55', '&b': '#55FFFF',
        '&c': '#FF5555', '&d': '#FF55FF', '&e': '#FFFF55', '&f': '#FFFFFF'
    };
    let style = '';
    let primaryColor = null;
    const colorCodes = permissionString.match(/&[0-9a-fk-or]/g) || [];
    
    colorCodes.forEach(code => {
        if (colorMap[code]) {
            if (!primaryColor) primaryColor = colorMap[code];
            style += `color: ${colorMap[code]};`;
        }
        if (code === '&l') style += 'font-weight: bold;';
        if (code === '&o') style += 'font-style: italic;';
        if (code === '&n') style += 'text-decoration: underline;';
        if (code === '&m') style += 'text-decoration: line-through;';
    });
    return { style, hexColor: primaryColor };
}


// --- Page Routes (Publicly Accessible) ---

// The root now serves the HOME page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'home.html'));
});

// Route for the login page
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'login.html'));
});

// Route for the players page
app.get('/players', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'players.html'));
});

// Route for the profile page
app.get('/profile/:username', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'profile.html'));
});

app.get('/staff/my-stats', isStaff, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html', 'my-stats.html'));
});
app.get('/api/my-stats', isAuthenticated, async (req, res) => {
    try {
        const username = req.session.user.username;
        res.setHeader('Cache-Control', 'no-store');

        const sql = `
            SELECT
                lp.username, lp.primary_group, lp.uuid,
                db.playtime,
                pvp.points, pvp.kills, pvp.deaths, pvp.shards
            FROM luckperms_players AS lp
            LEFT JOIN deepbungee AS db ON lp.uuid = db.uuid
            LEFT JOIN pvp_nullping AS pvp ON lp.uuid = pvp.uuid
            WHERE lp.username = ?
        `;

        const [rows] = await dbPool.execute(sql, [username]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Player stats not found' });
        }

        res.json(rows[0]);

    } catch (dbError) {
        console.error('Database query error (my-stats):', dbError);
        res.status(500).json({ error: 'Failed to fetch your stats.' });
    }
});

app.get('/staff/my-bans', isStaff, (req, res) => {
    res.send('<h1>My Bans Page (Work in Progress)</h1>');
});

app.get('/staff/top-bans', isStaff, (req, res) => {
    res.send('<h1>Top Bans Page (Work in Progress)</h1>');
});
// --- API Endpoints ---

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        // Step 1: Authenticate against the 'auth_users' table
        const [authRows] = await dbPool.execute('SELECT * FROM `auth_users` WHERE `username` = ?', [username]);
        if (authRows.length === 0) {
            return res.json({ success: false, message: 'Invalid username or password.' });
        }
        const userAuth = authRows[0];
        const passwordMatch = await bcrypt.compare(password, userAuth.password);

        if (passwordMatch) {
            // Step 2: If auth is successful, get required data from other tables
            const [playerDataRows] = await dbPool.execute(
                `SELECT lp.uuid, lp.primary_group 
                 FROM luckperms_players AS lp 
                 WHERE lp.username = ?`,
                [username]
            );

            if (playerDataRows.length === 0) {
                return res.status(404).json({ success: false, message: 'Could not find player permission data.' });
            }
            const playerData = playerDataRows[0];

            // Set the user as online
            await dbPool.execute('UPDATE `auth_users` SET `is_logged_in` = 1 WHERE `username` = ?', [username]);

            // Step 3: Create the session with all correct data
            req.session.user = {
                username: userAuth.username,
                ign: username,
                uuid: playerData.uuid,
                primary_group: playerData.primary_group // <-- Get group from luckperms_players
            };
            
            req.session.save(err => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Server error during login.' });
                }
                res.json({ success: true, message: `Successfully logged in!` });
            });
        } else {
            res.json({ success: false, message: 'Invalid username or password.' });
        }
    } catch (dbError) {
        console.error('[Server] Database or bcrypt error:', dbError);
        res.status(500).json({ success: false, message: 'A server error occurred.' });
    }
});

app.post('/logout', isAuthenticated, (req, res) => {
    const username = req.session.user.username;
    dbPool.execute('UPDATE `auth_users` SET `is_logged_in` = 0 WHERE `username` = ?', [username])
        .then(() => {
            req.session.destroy(err => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Could not log out.' });
                }
                res.clearCookie('connect.sid');
                return res.json({ success: true, message: 'Logged out successfully.' });
            });
        })
        .catch(dbError => {
            res.status(500).json({ success: false, message: 'Error during logout.' });
        });
});

app.get('/api/auth/status', async (req, res) => {
    if (req.session.user) {
        try {
            // ✅ FIX: Re-fetch the user's current group from the database on every page load
            const [rows] = await dbPool.execute(
                'SELECT primary_group FROM `luckperms_players` WHERE `username` = ?',
                [req.session.user.username]
            );

            if (rows.length === 0) {
                // If the user was deleted from LuckPerms, destroy their session
                return req.session.destroy(() => {
                    res.json({ loggedIn: false });
                });
            }

            // Update the session with the latest group
            req.session.user.primary_group = rows[0].primary_group;

            // Send the updated user object to the browser
            res.json({ loggedIn: true, user: req.session.user });

        } catch (dbError) {
            console.error('[Server] Error re-fetching user group:', dbError);
            res.status(500).json({ error: 'Failed to verify user status.' });
        }
    } else {
        res.json({ loggedIn: false });
    }
});

app.get('/api/news', (req, res) => {
    const newsData = [
        { id: 1, title: "New Server Update v1.2!", content: "A massive update with new quests and a PVP arena.", author: "DeepMC Admin", date: "2025-07-28" },
        { id: 2, title: "Summer Event Coming Soon", content: "Get ready for exclusive items and new mini-games!", author: "DeepMC Admin", date: "2025-07-25" }
    ];
    res.json(newsData);
});

app.get('/api/top-playtime', async (req, res) => {
    try {
        res.setHeader('Cache-Control', 'no-store');
        const [rows] = await dbPool.execute(`
            SELECT db.ign AS username, db.playtime, lgp.permission AS suffix_permission
            FROM deepbungee AS db
            LEFT JOIN luckperms_players AS lp ON db.uuid = lp.uuid
            LEFT JOIN luckperms_group_permissions AS lgp ON lp.primary_group = lgp.name AND lgp.permission LIKE 'suffix.%'
            ORDER BY db.playtime DESC
            LIMIT 5
        `);
        const playersWithColors = rows.map(player => {
            const { style } = player.suffix_permission ? parseMinecraftColors(player.suffix_permission) : { style: '' };
            return { ...player, colorStyle: style };
        });
        res.json(playersWithColors);
    } catch (dbError) {
        res.status(500).json({ error: 'Failed to fetch top players.' });
    }
});

app.get('/api/staff', async (req, res) => {
    try {
        res.setHeader('Cache-Control', 'no-store');

        const rankOrder = ['owner', 'manager', 'headadmin', 'admin', 'seniormod', 'mod'];
        const placeholders = rankOrder.map(() => '?').join(',');

        const sqlQuery = `
            SELECT
                lp.username,
                lp.primary_group,
                lp.uuid,
                db.playtime,
                au.is_logged_in,
                lgp.permission AS suffix_permission
            FROM
                luckperms_players AS lp
            LEFT JOIN
                deepbungee AS db ON lp.uuid = db.uuid
            LEFT JOIN
                auth_users AS au ON lp.uuid = au.uuid
            LEFT JOIN
                luckperms_group_permissions AS lgp
                ON lp.primary_group = lgp.name AND lgp.permission LIKE 'suffix.%'
            WHERE
                lp.primary_group IN (${placeholders})
            ORDER BY
                FIELD(lp.primary_group, ${placeholders})
        `;

        // Use the ranks twice: once for IN(), once for FIELD()
        const sqlParams = [...rankOrder, ...rankOrder];

        const [rows] = await dbPool.execute(sqlQuery, sqlParams);

        const playersWithColors = rows.map(player => {
            const { style, hexColor } = player.suffix_permission
                ? parseMinecraftColors(player.suffix_permission)
                : { style: '', hexColor: '#00AAAA' };
            return { ...player, colorStyle: style, rankColor: hexColor || '#00AAAA' };
        });

        res.json(playersWithColors);
    } catch (dbError) {
        console.error('Database query error (staff):', dbError);
        res.status(500).json({ error: 'Failed to fetch staff list.' });
    }
});


app.get('/api/player/:username', async (req, res) => {
    try {
        const username = req.params.username;
        res.setHeader('Cache-Control', 'no-store');
        const sql = `
            SELECT lp.username, lp.primary_group, lp.uuid, db.playtime, au.is_logged_in, lgp.permission AS suffix_permission,
                   pvp.points, pvp.kills, pvp.deaths, pvp.shards
            FROM luckperms_players AS lp
            LEFT JOIN deepbungee AS db ON lp.uuid = db.uuid
            LEFT JOIN auth_users AS au ON lp.uuid = au.uuid
            LEFT JOIN luckperms_group_permissions AS lgp ON lp.primary_group = lgp.name AND lgp.permission LIKE 'suffix.%'
            LEFT JOIN pvp_nullping AS pvp ON lp.uuid = pvp.uuid
            WHERE lp.username = ?
        `;
        const [rows] = await dbPool.execute(sql, [username]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Player not found' });
        }
        const player = rows[0];
        const { style, hexColor } = player.suffix_permission ? parseMinecraftColors(player.suffix_permission) : { style: '', hexColor: '#00AAAA' };
        res.json({ ...player, colorStyle: style, rankColor: hexColor || '#00AAAA' });
    } catch (dbError) {
        res.status(500).json({ error: 'Failed to fetch player profile.' });
    }
});

// --- Server Start ---
app.listen(PORT, () => {
    console.log(`DeepMC server running at http://localhost:${PORT}`);
});